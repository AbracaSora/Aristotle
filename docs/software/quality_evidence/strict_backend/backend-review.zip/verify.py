"""Replay the backend review in a new detached clone and check every patch and resulting tree."""
import argparse
import difflib
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile


def git(repo, *args):
    return subprocess.check_output(["git", *args], cwd=repo, stderr=subprocess.PIPE)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def verify(bundle, origin, target):
    manifest = json.loads((bundle / "manifest.json").read_text())
    git(origin, "clone", "--quiet", "--no-hardlinks", "--no-checkout", ".", str(target))
    git(target, "checkout", "--quiet", "--detach", manifest["base"])
    git(target, "remote", "remove", "origin")
    for number, entry in enumerate(manifest["batches"], 1):
        patch = bundle / entry["patch"]
        path = target / entry["file"]
        before = path.read_text().splitlines() if path.exists() else []
        if sha(patch.read_bytes()) != entry["sha256"]:
            raise ValueError(f"Patch {number} checksum mismatch")
        a, d, changed = git(target, "apply", "--numstat", str(patch)).decode().rstrip().split("\t")
        if (int(a), int(d), changed) != (entry["added"], entry["deleted"], entry["file"]):
            raise ValueError(f"Patch {number} numstat mismatch")
        git(target, "apply", "--check", "--index", str(patch))
        git(target, "apply", "--index", str(patch))
        tree = git(target, "write-tree").decode().strip()
        if tree != entry["tree"]:
            raise ValueError(f"Patch {number} tree mismatch")
        current = path.read_text()
        compile(current, str(path), "exec")
        count = sum(x.startswith(("+ ", "- ")) for x in difflib.ndiff(before, current.splitlines()))
        if count != entry["guard_lines"] or max(count, int(a) + int(d)) > 400:
            raise ValueError(f"Patch {number} exceeds threshold or manifest differs")
        print(f"{number:02}  +{a} -{d}  TH-11={count}  {entry['patch']}")
    actual = {
        str(p.relative_to(target)): sha(p.read_bytes())
        for folder in manifest["sources"]
        for p in (target / folder).rglob("*.py")
    }
    if actual != manifest["files"]:
        raise ValueError("Final source tree differs from the recorded working copy")
    print(f"Verified {len(manifest['batches'])} patches and {len(actual)} final source files")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, help="Any local repository containing the baseline")
    args = parser.parse_args()
    bundle = Path(__file__).resolve().parent
    with tempfile.TemporaryDirectory(prefix="aristotle-replay-") as directory:
        verify(bundle, (args.repo or bundle / "checkout").resolve(), Path(directory) / "checkout")


if __name__ == "__main__":
    main()
